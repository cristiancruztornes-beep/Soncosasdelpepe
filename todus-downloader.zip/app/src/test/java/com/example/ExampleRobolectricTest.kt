package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.DownloadEntity
import com.example.data.model.DownloadStatus
import com.example.data.network.TodusHttp
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun readStringFromContext() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Todus Downloader", appName)
    }

    @Test
    fun extractFileNameFromTodusUrl() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val todusHttp = TodusHttp.getInstance(context)
        val url = "https://s3.todus.cu/stream/users/df/8535855910/lXiGB9dMJVMsTMfUt0jo_ep00zNY-w1w.mp4"
        val fileName = todusHttp.extractFileName(url, null)
        assertEquals("lXiGB9dMJVMsTMfUt0jo_ep00zNY-w1w.mp4", fileName)
    }

    @Test
    fun formatBytesFormatting() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val todusHttp = TodusHttp.getInstance(context)

        assertEquals("500.0 KB", todusHttp.formatBytes(500 * 1024))
        assertEquals("10.00 MB", todusHttp.formatBytes(10 * 1024 * 1024))
        assertEquals("1.50 GB", todusHttp.formatBytes((1.5 * 1024 * 1024 * 1024).toLong()))
    }

    @Test
    fun roomDatabaseInsertAndQuery() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = AppDatabase.getInstance(context)
        val dao = db.downloadDao()

        val entity = DownloadEntity(
            id = "test-id-1",
            url = "https://s3.todus.cu/test.mp4",
            fileName = "test.mp4",
            filePath = "/fake/path/test.mp4",
            totalBytes = 1000L,
            downloadedBytes = 500L,
            status = DownloadStatus.DOWNLOADING.name,
            supportsResume = true
        )

        dao.insertDownload(entity)
        val queried = dao.getDownloadById("test-id-1")
        assertNotNull(queried)
        assertEquals("test.mp4", queried?.fileName)
        assertEquals(500L, queried?.downloadedBytes)

        dao.deleteById("test-id-1")
    }

    @Test
    fun launchMainActivityDoesNotCrash() {
        val controller = org.robolectric.Robolectric.buildActivity(MainActivity::class.java).setup()
        assertNotNull(controller.get())
    }
}
