package com.example.data.model

enum class DownloadStatus {
    PENDING,
    CONNECTING,
    DOWNLOADING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class UrlAnalysisResult(
    val url: String,
    val fileName: String,
    val contentLength: Long,
    val formattedSize: String,
    val contentType: String,
    val isProgressiveSupported: Boolean,
    val isResumable: Boolean,
    val statusCode: Int,
    val isSuccess: Boolean,
    val errorMessage: String? = null
)

data class DownloadInfo(
    val id: String,
    val url: String,
    val fileName: String,
    val filePath: String,
    val totalBytes: Long,
    val downloadedBytes: Long,
    val progressPercent: Int,
    val speedBytesPerSec: Long,
    val status: DownloadStatus,
    val supportsResume: Boolean,
    val errorMessage: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
)
