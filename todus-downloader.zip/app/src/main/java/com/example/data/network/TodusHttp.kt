package com.example.data.network

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import com.example.data.model.UrlAnalysisResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.TimeUnit

class TodusHttp private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("todus_prefs", Context.MODE_PRIVATE)

    companion object {
        const val DEFAULT_USER_AGENT = "Todus/1.5.0 (Android; Mobile; rv:102)"
        const val KEY_CUSTOM_UA = "custom_user_agent"
        const val KEY_AUTH_TOKEN = "auth_token"
        const val KEY_MAX_CONCURRENT = "max_concurrent_downloads"

        @Volatile
        private var INSTANCE: TodusHttp? = null

        fun getInstance(context: Context): TodusHttp {
            return INSTANCE ?: synchronized(this) {
                val instance = TodusHttp(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }

    var customUserAgent: String
        get() = prefs.getString(KEY_CUSTOM_UA, DEFAULT_USER_AGENT) ?: DEFAULT_USER_AGENT
        set(value) = prefs.edit().putString(KEY_CUSTOM_UA, value).apply()

    var authToken: String
        get() = prefs.getString(KEY_AUTH_TOKEN, "") ?: ""
        set(value) = prefs.edit().putString(KEY_AUTH_TOKEN, value).apply()

    var maxConcurrentDownloads: Int
        get() = prefs.getInt(KEY_MAX_CONCURRENT, 3)
        set(value) = prefs.edit().putInt(KEY_MAX_CONCURRENT, value).apply()

    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                val original = chain.request()
                val builder = original.newBuilder()

                // Preserve original URL strictly without modifying query or path
                val ua = customUserAgent.ifBlank { DEFAULT_USER_AGENT }
                builder.header("User-Agent", ua)
                builder.header("Accept", "*/*")
                // Identity encoding ensures range requests and progress calculation work directly on raw bytes
                if (original.header("Accept-Encoding") == null) {
                    builder.header("Accept-Encoding", "identity")
                }
                builder.header("Connection", "keep-alive")

                // Add legit user authorization if provided
                val token = authToken.trim()
                if (token.isNotEmpty() && original.header("Authorization") == null) {
                    val authHeaderValue = if (token.startsWith("Bearer ", ignoreCase = true) ||
                        token.startsWith("Basic ", ignoreCase = true)
                    ) {
                        token
                    } else {
                        "Bearer $token"
                    }
                    builder.header("Authorization", authHeaderValue)
                }

                chain.proceed(builder.build())
            }
            .build()
    }

    /**
     * Probes the given URL by sending a HEAD request (or fallback GET bytes 0-1)
     * to inspect Content-Length, Content-Type, Accept-Ranges and filename.
     */
    suspend fun analyzeUrl(url: String): UrlAnalysisResult = withContext(Dispatchers.IO) {
        val trimmed = url.trim()
        if (trimmed.isBlank() || (!trimmed.startsWith("http://") && !trimmed.startsWith("https://"))) {
            return@withContext UrlAnalysisResult(
                url = trimmed,
                fileName = "video.mp4",
                contentLength = 0L,
                formattedSize = "Desconocido",
                contentType = "unknown",
                isProgressiveSupported = false,
                isResumable = false,
                statusCode = 0,
                isSuccess = false,
                errorMessage = "URL no válida. Debe comenzar con http:// o https://"
            )
        }

        var response: Response? = null
        try {
            // First attempt: HEAD request to probe metadata without downloading body
            val headReq = Request.Builder()
                .url(trimmed)
                .head()
                .build()

            response = try {
                client.newCall(headReq).execute()
            } catch (e: Exception) {
                null
            }

            // If HEAD was rejected (e.g. 405 Method Not Allowed or 403), probe using a tiny GET with Range header
            if (response == null || !response.isSuccessful || response.code == 405) {
                response?.close()
                val probeGetReq = Request.Builder()
                    .url(trimmed)
                    .header("Range", "bytes=0-1024")
                    .get()
                    .build()
                response = client.newCall(probeGetReq).execute()
            }

            val statusCode = response.code
            val isSuccess = response.isSuccessful || statusCode == 206

            if (!isSuccess) {
                val errorMsg = when (statusCode) {
                    401 -> "Acceso no autorizado (401). El enlace requiere credenciales o token de acceso."
                    403 -> "Acceso denegado (403). El servidor rechazó la solicitud o el enlace ha caducado."
                    404 -> "Archivo no encontrado (404). Verifica que el enlace sea correcto."
                    500, 502, 503 -> "Error del servidor Todus ($statusCode). Inténtalo más tarde."
                    else -> "El servidor respondió con código HTTP $statusCode."
                }
                return@withContext UrlAnalysisResult(
                    url = trimmed,
                    fileName = extractFileName(trimmed, null),
                    contentLength = 0L,
                    formattedSize = "0 MB",
                    contentType = response.header("Content-Type") ?: "video/mp4",
                    isProgressiveSupported = false,
                    isResumable = false,
                    statusCode = statusCode,
                    isSuccess = false,
                    errorMessage = errorMsg
                )
            }

            // Extract content-length
            var length = response.header("Content-Length")?.toLongOrNull() ?: 0L
            val contentRange = response.header("Content-Range")
            if (contentRange != null) {
                // Content-Range: bytes 0-1024/15893022
                val slashIdx = contentRange.lastIndexOf('/')
                if (slashIdx != -1) {
                    val totalFromRange = contentRange.substring(slashIdx + 1).trim().toLongOrNull()
                    if (totalFromRange != null && totalFromRange > 0) {
                        length = totalFromRange
                    }
                }
            }

            val acceptRanges = response.header("Accept-Ranges")
            val isResumable = (acceptRanges?.contains("bytes", ignoreCase = true) == true) ||
                    statusCode == 206 ||
                    contentRange != null

            val isProgressiveSupported = isResumable || statusCode == 200 || statusCode == 206
            val contentType = response.header("Content-Type") ?: "video/mp4"
            val disposition = response.header("Content-Disposition")
            val fileName = extractFileName(trimmed, disposition)

            return@withContext UrlAnalysisResult(
                url = trimmed,
                fileName = fileName,
                contentLength = length,
                formattedSize = formatBytes(length),
                contentType = contentType,
                isProgressiveSupported = isProgressiveSupported,
                isResumable = isResumable,
                statusCode = statusCode,
                isSuccess = true,
                errorMessage = null
            )
        } catch (e: IOException) {
            return@withContext UrlAnalysisResult(
                url = trimmed,
                fileName = extractFileName(trimmed, null),
                contentLength = 0L,
                formattedSize = "Desconocido",
                contentType = "unknown",
                isProgressiveSupported = false,
                isResumable = false,
                statusCode = 0,
                isSuccess = false,
                errorMessage = "Error de conexión: ${e.localizedMessage ?: "No se pudo conectar al servidor"}"
            )
        } catch (e: Exception) {
            return@withContext UrlAnalysisResult(
                url = trimmed,
                fileName = extractFileName(trimmed, null),
                contentLength = 0L,
                formattedSize = "Desconocido",
                contentType = "unknown",
                isProgressiveSupported = false,
                isResumable = false,
                statusCode = 0,
                isSuccess = false,
                errorMessage = "Error al analizar: ${e.localizedMessage}"
            )
        } finally {
            response?.close()
        }
    }

    /**
     * Extracts a safe and descriptive filename from Content-Disposition or the URL path.
     */
    fun extractFileName(url: String, contentDisposition: String?): String {
        if (!contentDisposition.isNullOrBlank()) {
            val patterns = listOf(
                "filename\\*=UTF-8''([^;]+)".toRegex(RegexOption.IGNORE_CASE),
                "filename=\"([^\"]+)\"".toRegex(RegexOption.IGNORE_CASE),
                "filename=([^;\\s]+)".toRegex(RegexOption.IGNORE_CASE)
            )
            for (p in patterns) {
                val match = p.find(contentDisposition)
                if (match != null) {
                    val rawName = Uri.decode(match.groupValues[1])
                    val sanitized = sanitizeFileName(rawName)
                    if (sanitized.isNotBlank()) return sanitized
                }
            }
        }

        try {
            val uri = Uri.parse(url)
            val lastSegment = uri.lastPathSegment
            if (!lastSegment.isNullOrBlank()) {
                val sanitized = sanitizeFileName(lastSegment)
                if (sanitized.isNotBlank()) {
                    return if (sanitized.endsWith(".mp4", ignoreCase = true)) {
                        sanitized
                    } else {
                        "$sanitized.mp4"
                    }
                }
            }
        } catch (_: Exception) {
        }

        return "todus_video_${System.currentTimeMillis()}.mp4"
    }

    private fun sanitizeFileName(name: String): String {
        return name.replace("[\\\\/:*?\"<>|]".toRegex(), "_").trim()
    }

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "Desconocido"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1.0 -> String.format("%.2f GB", gb)
            mb >= 1.0 -> String.format("%.2f MB", mb)
            else -> String.format("%.1f KB", kb)
        }
    }

    fun formatSpeed(bytesPerSec: Long): String {
        if (bytesPerSec <= 0) return "0 KB/s"
        val kb = bytesPerSec / 1024.0
        val mb = kb / 1024.0
        return if (mb >= 1.0) {
            String.format("%.2f MB/s", mb)
        } else {
            String.format("%.1f KB/s", kb)
        }
    }
}
