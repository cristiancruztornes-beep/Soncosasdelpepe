package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.DownloadInfo
import com.example.data.model.DownloadStatus

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey
    val id: String,
    val url: String,
    val fileName: String,
    val filePath: String,
    val totalBytes: Long,
    val downloadedBytes: Long,
    val status: String,
    val supportsResume: Boolean,
    val errorMessage: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
) {
    fun toDomainModel(currentSpeed: Long = 0L): DownloadInfo {
        val pct = if (totalBytes > 0) {
            ((downloadedBytes.toDouble() / totalBytes) * 100).toInt().coerceIn(0, 100)
        } else if (status == DownloadStatus.COMPLETED.name) {
            100
        } else 0

        val parsedStatus = try {
            DownloadStatus.valueOf(status)
        } catch (e: Exception) {
            DownloadStatus.FAILED
        }

        return DownloadInfo(
            id = id,
            url = url,
            fileName = fileName,
            filePath = filePath,
            totalBytes = totalBytes,
            downloadedBytes = downloadedBytes,
            progressPercent = pct,
            speedBytesPerSec = currentSpeed,
            status = parsedStatus,
            supportsResume = supportsResume,
            errorMessage = errorMessage,
            createdAt = createdAt,
            completedAt = completedAt
        )
    }

    companion object {
        fun fromDomain(info: DownloadInfo): DownloadEntity {
            return DownloadEntity(
                id = info.id,
                url = info.url,
                fileName = info.fileName,
                filePath = info.filePath,
                totalBytes = info.totalBytes,
                downloadedBytes = info.downloadedBytes,
                status = info.status.name,
                supportsResume = info.supportsResume,
                errorMessage = info.errorMessage,
                createdAt = info.createdAt,
                completedAt = info.completedAt
            )
        }
    }
}
