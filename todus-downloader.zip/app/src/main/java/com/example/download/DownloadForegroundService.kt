package com.example.download

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.model.DownloadStatus
import com.example.data.network.TodusHttp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class DownloadForegroundService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var observerJob: Job? = null
    private lateinit var engine: DownloadEngine
    private lateinit var todusHttp: TodusHttp
    private lateinit var database: AppDatabase

    companion object {
        const val CHANNEL_ID = "todus_downloads_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START_DOWNLOAD = "com.example.todus.START_DOWNLOAD"
        const val ACTION_PAUSE_DOWNLOAD = "com.example.todus.PAUSE_DOWNLOAD"
        const val ACTION_CANCEL_DOWNLOAD = "com.example.todus.CANCEL_DOWNLOAD"
        const val EXTRA_DOWNLOAD_ID = "extra_download_id"

        fun startService(context: Context) {
            val intent = Intent(context, DownloadForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        engine = DownloadEngine.getInstance(this)
        todusHttp = TodusHttp.getInstance(this)
        database = AppDatabase.getInstance(this)

        createNotificationChannel()
        startAsForeground()

        observeDownloads()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let {
            val action = it.action
            val downloadId = it.getStringExtra(EXTRA_DOWNLOAD_ID)
            if (downloadId != null) {
                when (action) {
                    ACTION_PAUSE_DOWNLOAD -> engine.pauseDownload(downloadId)
                    ACTION_CANCEL_DOWNLOAD -> engine.cancelDownload(downloadId)
                    ACTION_START_DOWNLOAD -> engine.startDownload(downloadId)
                }
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        observerJob?.cancel()
    }

    private fun startAsForeground() {
        val notification = buildNotification("Iniciando descargas...", 0, 0, 0L)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun observeDownloads() {
        observerJob = scope.launch {
            database.downloadDao().getAllDownloads().collectLatest { entities ->
                val active = entities.filter {
                    it.status == DownloadStatus.DOWNLOADING.name || it.status == DownloadStatus.CONNECTING.name
                }

                if (active.isEmpty()) {
                    // Check if there are no more active jobs in engine
                    if (engine.activeDownloadsCount.value == 0) {
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                        return@collectLatest
                    }
                }

                val count = active.size
                var totalBytes = 0L
                var downloadedBytes = 0L
                var totalSpeed = 0L

                for (item in active) {
                    totalBytes += item.totalBytes
                    downloadedBytes += item.downloadedBytes
                    totalSpeed += engine.getSpeed(item.id)
                }

                val overallProgress = if (totalBytes > 0) {
                    ((downloadedBytes.toDouble() / totalBytes) * 100).toInt().coerceIn(0, 100)
                } else 0

                val primaryName = active.firstOrNull()?.fileName ?: "Archivos MP4"
                val contentText = if (count > 1) {
                    "$count descargas en curso (${todusHttp.formatSpeed(totalSpeed)})"
                } else {
                    "$primaryName • ${todusHttp.formatSpeed(totalSpeed)}"
                }

                val notification = buildNotification(contentText, overallProgress, count, totalSpeed)
                val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                manager.notify(NOTIFICATION_ID, notification)
            }
        }
    }

    private fun buildNotification(
        contentText: String,
        progress: Int,
        activeCount: Int,
        totalSpeed: Long
    ): android.app.Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_todus_logo)
            .setContentTitle("Todus Downloader")
            .setContentText(contentText)
            .setProgress(100, progress, progress <= 0)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pendingOpen)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Descargas de Todus Downloader",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notificaciones de progreso para descargas de vídeo"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }
}
