package com.example.download

import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.local.DownloadEntity
import com.example.data.model.DownloadInfo
import com.example.data.model.DownloadStatus
import com.example.data.network.TodusHttp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.Request
import okhttp3.Response
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class DownloadEngine private constructor(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val database = AppDatabase.getInstance(context)
    private val dao = database.downloadDao()
    private val todusHttp = TodusHttp.getInstance(context)

    // Active downloading jobs mapped by downloadId
    private val activeJobs = ConcurrentHashMap<String, Job>()
    // Live speeds (bytes per second)
    private val activeSpeeds = ConcurrentHashMap<String, Long>()

    private val _activeDownloadsCount = MutableStateFlow(0)
    val activeDownloadsCount: StateFlow<Int> = _activeDownloadsCount.asStateFlow()

    companion object {
        private const val TAG = "DownloadEngine"
        const val FOLDER_NAME = "Todus Downloader"

        @Volatile
        private var INSTANCE: DownloadEngine? = null

        fun getInstance(context: Context): DownloadEngine {
            return INSTANCE ?: synchronized(this) {
                val instance = DownloadEngine(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }

    /**
     * Resolves the target directory "Todus Downloader".
     */
    fun getDownloadDirectory(): File {
        // Try public Download/Todus Downloader directory first
        val publicDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val target = File(publicDownloads, FOLDER_NAME)
        if (target.exists() || target.mkdirs()) {
            return target
        }
        // Fallback to app external files directory
        val extMovies = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
        val fallback = File(extMovies ?: context.filesDir, FOLDER_NAME)
        if (!fallback.exists()) fallback.mkdirs()
        return fallback
    }

    /**
     * Enqueues a new download.
     */
    suspend fun enqueueDownload(
        url: String,
        suggestedFileName: String?,
        totalBytes: Long,
        supportsResume: Boolean
    ): String {
        val id = UUID.randomUUID().toString()
        val dir = getDownloadDirectory()
        val rawName = suggestedFileName ?: todusHttp.extractFileName(url, null)
        val file = getUniqueFile(dir, rawName)

        val entity = DownloadEntity(
            id = id,
            url = url,
            fileName = file.name,
            filePath = file.absolutePath,
            totalBytes = totalBytes,
            downloadedBytes = 0L,
            status = DownloadStatus.PENDING.name,
            supportsResume = supportsResume,
            createdAt = System.currentTimeMillis()
        )
        dao.insertDownload(entity)

        startDownload(id)
        return id
    }

    /**
     * Starts or resumes a download task by ID.
     */
    fun startDownload(id: String) {
        if (activeJobs.containsKey(id)) {
            Log.d(TAG, "Download $id is already running")
            return
        }

        val job = scope.launch {
            val entity = dao.getDownloadById(id) ?: return@launch
            runDownloadLoop(entity)
        }

        activeJobs[id] = job
        updateActiveCount()
    }

    /**
     * Pauses an active download.
     */
    fun pauseDownload(id: String) {
        val job = activeJobs.remove(id)
        activeSpeeds.remove(id)
        job?.cancel()
        scope.launch {
            dao.updateStatus(id, DownloadStatus.PAUSED.name, null)
            updateActiveCount()
        }
    }

    /**
     * Cancels a download and optionally removes partial file.
     */
    fun cancelDownload(id: String, deleteFile: Boolean = true) {
        val job = activeJobs.remove(id)
        activeSpeeds.remove(id)
        job?.cancel()
        scope.launch {
            val entity = dao.getDownloadById(id)
            if (deleteFile && entity != null) {
                val f = File(entity.filePath)
                if (f.exists()) f.delete()
            }
            dao.updateStatus(id, DownloadStatus.CANCELLED.name, "Descarga cancelada por el usuario")
            updateActiveCount()
        }
    }

    /**
     * Deletes a download from history and optionally removes file from storage.
     */
    fun deleteRecord(id: String, deleteFileFromDisk: Boolean = true) {
        val job = activeJobs.remove(id)
        activeSpeeds.remove(id)
        job?.cancel()
        scope.launch {
            val entity = dao.getDownloadById(id)
            if (deleteFileFromDisk && entity != null) {
                val f = File(entity.filePath)
                if (f.exists()) f.delete()
            }
            dao.deleteById(id)
            updateActiveCount()
        }
    }

    fun getSpeed(id: String): Long {
        return activeSpeeds[id] ?: 0L
    }

    private suspend fun runDownloadLoop(entity: DownloadEntity) {
        val targetFile = File(entity.filePath)
        val existingBytes = if (targetFile.exists()) targetFile.length() else 0L

        // Update state to CONNECTING
        dao.updateStatus(entity.id, DownloadStatus.CONNECTING.name, null)

        var response: Response? = null
        try {
            val requestBuilder = Request.Builder().url(entity.url)

            val useResume = entity.supportsResume && existingBytes > 0
            if (useResume) {
                requestBuilder.header("Range", "bytes=$existingBytes-")
            }

            val request = requestBuilder.build()
            response = todusHttp.client.newCall(request).execute()

            val statusCode = response.code
            val isPartial = statusCode == 206
            val isOk = statusCode == 200

            if (!isPartial && !isOk) {
                val errorMsg = "Error HTTP $statusCode: ${response.message}"
                dao.updateStatus(entity.id, DownloadStatus.FAILED.name, errorMsg)
                return
            }

            // Determine effective file length
            var totalLength = entity.totalBytes
            val body = response.body
            val bodyLength = body?.contentLength() ?: -1L

            if (isPartial) {
                if (bodyLength > 0) {
                    totalLength = existingBytes + bodyLength
                }
            } else if (isOk && bodyLength > 0) {
                totalLength = bodyLength
            }

            dao.updateProgress(entity.id, existingBytes, DownloadStatus.DOWNLOADING.name)

            val inputStream = body?.byteStream()
            if (inputStream == null) {
                dao.updateStatus(entity.id, DownloadStatus.FAILED.name, "Cuerpo de respuesta vacío")
                return
            }

            // Ensure parent directories exist
            targetFile.parentFile?.mkdirs()

            val randomAccess = RandomAccessFile(targetFile, "rw")
            if (isPartial) {
                randomAccess.seek(existingBytes)
            } else {
                randomAccess.setLength(0) // Start fresh
            }

            val buffer = ByteArray(64 * 1024) // 64 KB buffer
            var bytesRead: Int
            var currentDownloaded = if (isPartial) existingBytes else 0L

            var lastDbUpdateTime = System.currentTimeMillis()
            var speedSampleTime = System.currentTimeMillis()
            var speedSampleBytes = 0L

            inputStream.use { stream ->
                randomAccess.use { output ->
                    while (stream.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                        currentDownloaded += bytesRead
                        speedSampleBytes += bytesRead

                        val now = System.currentTimeMillis()

                        // Calculate rolling speed every 500ms
                        val elapsedSpeed = now - speedSampleTime
                        if (elapsedSpeed >= 500) {
                            val speed = (speedSampleBytes * 1000L) / elapsedSpeed
                            activeSpeeds[entity.id] = speed
                            speedSampleTime = now
                            speedSampleBytes = 0L
                        }

                        // Flush progress to database every 800ms
                        if (now - lastDbUpdateTime >= 800) {
                            dao.updateProgress(entity.id, currentDownloaded, DownloadStatus.DOWNLOADING.name)
                            lastDbUpdateTime = now
                        }
                    }
                }
            }

            // Final state check
            val finalFileLength = targetFile.length()
            val isCompleted = (totalLength <= 0 && finalFileLength > 0) || (finalFileLength >= totalLength)

            if (isCompleted) {
                val updatedEntity = entity.copy(
                    downloadedBytes = finalFileLength,
                    totalBytes = if (totalLength > 0) totalLength else finalFileLength,
                    status = DownloadStatus.COMPLETED.name,
                    completedAt = System.currentTimeMillis(),
                    errorMessage = null
                )
                dao.insertDownload(updatedEntity)
                activeSpeeds.remove(entity.id)

                // Scan with MediaScanner so gallery, files and other apps immediately see the video
                try {
                    MediaScannerConnection.scanFile(
                        context,
                        arrayOf(targetFile.absolutePath),
                        arrayOf("video/mp4")
                    ) { path, uri ->
                        Log.d(TAG, "Scanned $path -> $uri")
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "MediaScanner error", e)
                }
            } else {
                dao.updateStatus(entity.id, DownloadStatus.FAILED.name, "Descarga incompleta")
            }

        } catch (c: CancellationException) {
            // Task was paused or cancelled intentionally
            Log.d(TAG, "Download ${entity.id} was cancelled or paused")
        } catch (e: Exception) {
            Log.e(TAG, "Download error for ${entity.id}", e)
            dao.updateStatus(
                entity.id,
                DownloadStatus.FAILED.name,
                "Error de red: ${e.localizedMessage ?: "Conexión perdida"}"
            )
        } finally {
            response?.close()
            activeJobs.remove(entity.id)
            activeSpeeds.remove(entity.id)
            updateActiveCount()
        }
    }

    private fun updateActiveCount() {
        _activeDownloadsCount.value = activeJobs.size
    }

    private fun getUniqueFile(dir: File, fileName: String): File {
        var file = File(dir, fileName)
        if (!file.exists()) return file

        val nameWithoutExt = fileName.substringBeforeLast(".")
        val ext = fileName.substringAfterLast(".", "mp4")
        var counter = 1
        while (file.exists()) {
            file = File(dir, "${nameWithoutExt}_$counter.$ext")
            counter++
        }
        return file
    }
}
