package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TodusDarkColorScheme = darkColorScheme(
    primary = TodusGreen,
    onPrimary = Color(0xFF003816),
    primaryContainer = TodusGreenContainer,
    onPrimaryContainer = OnTodusGreenContainer,
    inversePrimary = TodusGreenDark,

    secondary = EmeraldTeal,
    onSecondary = Color(0xFF003822),
    secondaryContainer = Color(0xFF005234),
    onSecondaryContainer = Color(0xFF76F8C3),

    tertiary = CyanAccent,
    onTertiary = Color(0xFF00363D),

    background = DeepBlack,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = DarkSurfaceBorder,
    outlineVariant = Color(0xFF222936),

    error = ErrorRed,
    onError = Color.White
)

@Composable
fun TodusDownloaderTheme(
    content: @Composable () -> Unit
) {
    // Professional unified dark theme for video downloader
    MaterialTheme(
        colorScheme = TodusDarkColorScheme,
        typography = Typography,
        content = content
    )
}
