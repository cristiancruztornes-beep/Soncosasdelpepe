package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.DownloadInfo
import com.example.data.model.DownloadStatus
import com.example.data.model.UrlAnalysisResult
import com.example.data.network.TodusHttp
import com.example.download.DownloadEngine
import com.example.download.DownloadForegroundService
import com.example.ui.player.VideoPlayerActivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class DownloadFilterTab {
    ALL,
    ACTIVE,
    COMPLETED,
    FAILED
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val todusHttp = TodusHttp.getInstance(application)
    private val downloadEngine = DownloadEngine.getInstance(application)
    private val database = AppDatabase.getInstance(application)
    private val dao = database.downloadDao()

    // Input URL state
    val inputUrl = MutableStateFlow("")

    // URL Analysis State
    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _analysisResult = MutableStateFlow<UrlAnalysisResult?>(null)
    val analysisResult: StateFlow<UrlAnalysisResult?> = _analysisResult.asStateFlow()

    // Filter tab
    val selectedFilter = MutableStateFlow(DownloadFilterTab.ALL)

    // Flow of all downloads with dynamic live speed
    val downloads: StateFlow<List<DownloadInfo>> = dao.getAllDownloads()
        .map { list ->
            list.map { entity ->
                val speed = downloadEngine.getSpeed(entity.id)
                entity.toDomainModel(speed)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Filtered downloads
    val filteredDownloads: StateFlow<List<DownloadInfo>> =
        downloads.map { list ->
            when (selectedFilter.value) {
                DownloadFilterTab.ALL -> list
                DownloadFilterTab.ACTIVE -> list.filter {
                    it.status == DownloadStatus.DOWNLOADING ||
                            it.status == DownloadStatus.CONNECTING ||
                            it.status == DownloadStatus.PENDING ||
                            it.status == DownloadStatus.PAUSED
                }
                DownloadFilterTab.COMPLETED -> list.filter { it.status == DownloadStatus.COMPLETED }
                DownloadFilterTab.FAILED -> list.filter {
                    it.status == DownloadStatus.FAILED || it.status == DownloadStatus.CANCELLED
                }
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Settings
    val customUserAgent = MutableStateFlow(todusHttp.customUserAgent)
    val authToken = MutableStateFlow(todusHttp.authToken)
    val maxConcurrent = MutableStateFlow(todusHttp.maxConcurrentDownloads)

    fun onUrlChanged(newUrl: String) {
        inputUrl.value = newUrl
        // Clear previous analysis if URL changes
        if (_analysisResult.value?.url != newUrl.trim()) {
            _analysisResult.value = null
        }
    }

    fun analyzeCurrentUrl() {
        val url = inputUrl.value.trim()
        if (url.isEmpty()) return

        viewModelScope.launch {
            _isAnalyzing.value = true
            try {
                val result = todusHttp.analyzeUrl(url)
                _analysisResult.value = result
            } finally {
                _isAnalyzing.value = false
            }
        }
    }

    fun playUrl(context: Context, url: String, title: String? = null) {
        val finalTitle = title ?: todusHttp.extractFileName(url, null)
        VideoPlayerActivity.launch(
            context = context,
            videoUrl = url,
            title = finalTitle,
            isLocal = false
        )
    }

    fun playLocalFile(context: Context, downloadInfo: DownloadInfo) {
        VideoPlayerActivity.launch(
            context = context,
            videoUrl = downloadInfo.filePath,
            title = downloadInfo.fileName,
            isLocal = true
        )
    }

    fun startDownloadFromInput(context: Context) {
        val url = inputUrl.value.trim()
        if (url.isEmpty()) return

        val analysis = _analysisResult.value
        val fileName = analysis?.fileName ?: todusHttp.extractFileName(url, null)
        val totalBytes = analysis?.contentLength ?: 0L
        val resumable = analysis?.isResumable ?: true

        viewModelScope.launch {
            downloadEngine.enqueueDownload(
                url = url,
                suggestedFileName = fileName,
                totalBytes = totalBytes,
                supportsResume = resumable
            )
            DownloadForegroundService.startService(context)
        }
    }

    fun pauseDownload(id: String) {
        downloadEngine.pauseDownload(id)
    }

    fun resumeDownload(context: Context, id: String) {
        downloadEngine.startDownload(id)
        DownloadForegroundService.startService(context)
    }

    fun cancelDownload(id: String) {
        downloadEngine.cancelDownload(id)
    }

    fun deleteDownload(id: String, deleteFile: Boolean = true) {
        downloadEngine.deleteRecord(id, deleteFile)
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            dao.deleteAll()
        }
    }

    fun saveSettings(userAgent: String, token: String, maxConcurrentDownloads: Int) {
        todusHttp.customUserAgent = userAgent
        todusHttp.authToken = token
        todusHttp.maxConcurrentDownloads = maxConcurrentDownloads

        customUserAgent.value = userAgent
        authToken.value = token
        maxConcurrent.value = maxConcurrentDownloads
    }
}
