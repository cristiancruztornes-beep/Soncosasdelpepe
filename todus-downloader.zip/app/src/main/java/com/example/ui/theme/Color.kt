package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark background and surface tones
val DeepBlack = Color(0xFF090D12)
val DarkSurface = Color(0xFF131820)
val DarkSurfaceElevated = Color(0xFF1C222D)
val DarkSurfaceBorder = Color(0xFF2A323F)
val DarkCardBackground = Color(0xFF161B24)

// Todus Electric Green Palette
val TodusGreen = Color(0xFF00E676)
val TodusGreenDark = Color(0xFF00C853)
val TodusGreenLight = Color(0xFF69F0AE)
val TodusGreenContainer = Color(0xFF00381A)
val OnTodusGreenContainer = Color(0xFF8CF8BE)

// Secondary & Accent colors
val EmeraldTeal = Color(0xFF10B981)
val CyanAccent = Color(0xFF00E5FF)
val WarningAmber = Color(0xFFFFB300)
val ErrorRed = Color(0xFFFF5252)

// Typography colors
val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF8B949E)
val TextMuted = Color(0xFF555E6B)
