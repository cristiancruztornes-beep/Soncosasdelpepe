package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Downloading
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.model.DownloadInfo
import com.example.data.model.DownloadStatus
import com.example.data.network.TodusHttp
import com.example.download.DownloadEngine
import com.example.ui.DownloadFilterTab
import com.example.ui.MainViewModel
import com.example.ui.theme.DarkCardBackground
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DeepBlack
import com.example.ui.theme.EmeraldTeal
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TodusGreen
import com.example.ui.theme.TodusGreenContainer
import com.example.ui.theme.WarningAmber
import java.io.File

@Composable
fun DownloadsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val filteredList by viewModel.filteredDownloads.collectAsState()
    val allDownloads by viewModel.downloads.collectAsState()
    val selectedFilter by viewModel.selectedFilter.collectAsState()

    var itemToDelete by remember { mutableStateOf<DownloadInfo?>(null) }
    var deleteFileCheckbox by remember { mutableStateOf(true) }
    var showClearAllDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepBlack)
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Gestor de Descargas",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimary
                )
                Text(
                    text = "${allDownloads.size} elementos en el historial",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            if (allDownloads.isNotEmpty()) {
                TextButton(
                    onClick = { showClearAllDialog = true },
                    modifier = Modifier.testTag("clear_history_button")
                ) {
                    Text(
                        text = "Limpiar Todo",
                        color = ErrorRed,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Filter Tabs
        val tabs = listOf(
            DownloadFilterTab.ALL to "Todas (${allDownloads.size})",
            DownloadFilterTab.ACTIVE to "En curso (${allDownloads.count { it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.CONNECTING || it.status == DownloadStatus.PAUSED }})",
            DownloadFilterTab.COMPLETED to "Completadas (${allDownloads.count { it.status == DownloadStatus.COMPLETED }})",
            DownloadFilterTab.FAILED to "Fallidas (${allDownloads.count { it.status == DownloadStatus.FAILED || it.status == DownloadStatus.CANCELLED }})"
        )

        ScrollableTabRow(
            selectedTabIndex = tabs.indexOfFirst { it.first == selectedFilter }.coerceAtLeast(0),
            containerColor = DeepBlack,
            contentColor = TodusGreen,
            edgePadding = 20.dp,
            indicator = { tabPositions ->
                val index = tabs.indexOfFirst { it.first == selectedFilter }.coerceAtLeast(0)
                if (index < tabPositions.size) {
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[index]),
                        color = TodusGreen,
                        height = 3.dp
                    )
                }
            },
            divider = {}
        ) {
            tabs.forEach { (tab, title) ->
                val isSelected = selectedFilter == tab
                Tab(
                    selected = isSelected,
                    onClick = { viewModel.selectedFilter.value = tab },
                    text = {
                        Text(
                            text = title,
                            color = if (isSelected) TodusGreen else TextSecondary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 14.sp
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Downloads List or Empty State
        if (filteredList.isEmpty()) {
            EmptyDownloadsState(selectedFilter)
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(filteredList, key = { it.id }) { download ->
                    DownloadCard(
                        download = download,
                        onPlay = { viewModel.playLocalFile(context, download) },
                        onPause = { viewModel.pauseDownload(download.id) },
                        onResume = { viewModel.resumeDownload(context, download.id) },
                        onCancel = { viewModel.cancelDownload(download.id) },
                        onDelete = {
                            itemToDelete = download
                            deleteFileCheckbox = true
                        },
                        onShare = { shareVideo(context, download.filePath, download.fileName) }
                    )
                }
            }
        }
    }

    // Delete Confirmation Dialog
    if (itemToDelete != null) {
        val item = itemToDelete!!
        AlertDialog(
            onDismissRequest = { itemToDelete = null },
            title = {
                Text(
                    text = "¿Eliminar descarga?",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    Text(
                        text = "¿Deseas eliminar el registro de \"${item.fileName}\"?",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { deleteFileCheckbox = !deleteFileCheckbox }
                    ) {
                        Checkbox(
                            checked = deleteFileCheckbox,
                            onCheckedChange = { deleteFileCheckbox = it },
                            colors = CheckboxDefaults.colors(checkedColor = TodusGreen)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Eliminar también el archivo del dispositivo",
                            color = TextPrimary,
                            fontSize = 13.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteDownload(item.id, deleteFile = deleteFileCheckbox)
                        itemToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text("Eliminar", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { itemToDelete = null }) {
                    Text("Cancelar", color = TextSecondary)
                }
            },
            containerColor = DarkCardBackground
        )
    }

    // Clear All Confirmation Dialog
    if (showClearAllDialog) {
        AlertDialog(
            onDismissRequest = { showClearAllDialog = false },
            title = {
                Text(
                    text = "¿Limpiar historial completo?",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "Esto borrará todos los registros del historial de descargas.",
                    color = TextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearAllHistory()
                        showClearAllDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text("Limpiar", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearAllDialog = false }) {
                    Text("Cancelar", color = TextSecondary)
                }
            },
            containerColor = DarkCardBackground
        )
    }
}

@Composable
fun DownloadCard(
    download: DownloadInfo,
    onPlay: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit
) {
    val context = LocalContext.current
    val todusHttp = remember { TodusHttp.getInstance(context) }

    Card(
        colors = CardDefaults.cardColors(containerColor = DarkCardBackground),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("download_item_${download.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: File Name & Status Chip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = when (download.status) {
                            DownloadStatus.COMPLETED -> TodusGreenContainer
                            DownloadStatus.DOWNLOADING -> EmeraldTeal.copy(alpha = 0.2f)
                            DownloadStatus.PAUSED -> WarningAmber.copy(alpha = 0.2f)
                            DownloadStatus.FAILED, DownloadStatus.CANCELLED -> ErrorRed.copy(alpha = 0.2f)
                            else -> DarkSurfaceElevated
                        },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = when (download.status) {
                                    DownloadStatus.COMPLETED -> Icons.Default.DownloadDone
                                    DownloadStatus.DOWNLOADING -> Icons.Default.Downloading
                                    DownloadStatus.PAUSED -> Icons.Default.Pause
                                    DownloadStatus.FAILED, DownloadStatus.CANCELLED -> Icons.Default.Error
                                    else -> Icons.Default.Videocam
                                },
                                contentDescription = null,
                                tint = when (download.status) {
                                    DownloadStatus.COMPLETED -> TodusGreen
                                    DownloadStatus.DOWNLOADING -> EmeraldTeal
                                    DownloadStatus.PAUSED -> WarningAmber
                                    DownloadStatus.FAILED, DownloadStatus.CANCELLED -> ErrorRed
                                    else -> TextSecondary
                                },
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = download.fileName,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (download.totalBytes > 0) {
                                "${todusHttp.formatBytes(download.downloadedBytes)} de ${todusHttp.formatBytes(download.totalBytes)}"
                            } else {
                                todusHttp.formatBytes(download.downloadedBytes)
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                StatusBadge(download.status)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Progress bar
            LinearProgressIndicator(
                progress = {
                    if (download.status == DownloadStatus.COMPLETED) 1f
                    else download.progressPercent / 100f
                },
                color = when (download.status) {
                    DownloadStatus.COMPLETED -> TodusGreen
                    DownloadStatus.DOWNLOADING -> EmeraldTeal
                    DownloadStatus.PAUSED -> WarningAmber
                    DownloadStatus.FAILED, DownloadStatus.CANCELLED -> ErrorRed
                    else -> TodusGreen
                },
                trackColor = DarkSurfaceElevated,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Progress and Speed Metrics Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${download.progressPercent}%",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = when (download.status) {
                        DownloadStatus.COMPLETED -> TodusGreen
                        DownloadStatus.DOWNLOADING -> EmeraldTeal
                        else -> TextSecondary
                    }
                )

                if (download.status == DownloadStatus.DOWNLOADING && download.speedBytesPerSec > 0) {
                    Text(
                        text = "⚡ ${todusHttp.formatSpeed(download.speedBytesPerSec)}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = TodusGreen
                    )
                } else if (download.status == DownloadStatus.FAILED && download.errorMessage != null) {
                    Text(
                        text = download.errorMessage,
                        style = MaterialTheme.typography.labelSmall,
                        color = ErrorRed,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                when (download.status) {
                    DownloadStatus.DOWNLOADING, DownloadStatus.CONNECTING -> {
                        // Pause Button
                        IconButton(
                            onClick = onPause,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(DarkSurfaceElevated)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Pause,
                                contentDescription = "Pausar",
                                tint = WarningAmber,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Cancel Button
                        IconButton(
                            onClick = onCancel,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(DarkSurfaceElevated)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Cancel,
                                contentDescription = "Cancelar",
                                tint = ErrorRed,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    DownloadStatus.PAUSED -> {
                        // Resume Button
                        Button(
                            onClick = onResume,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = TodusGreen,
                                contentColor = DeepBlack
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Reanudar", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = onCancel,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(DarkSurfaceElevated)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Cancel,
                                contentDescription = "Cancelar",
                                tint = ErrorRed,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    DownloadStatus.COMPLETED -> {
                        // Play Video
                        Button(
                            onClick = onPlay,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = TodusGreen,
                                contentColor = DeepBlack
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Reproducir", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Share
                        IconButton(
                            onClick = onShare,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(DarkSurfaceElevated)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Compartir",
                                tint = TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Delete
                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(DarkSurfaceElevated)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Eliminar",
                                tint = TextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    DownloadStatus.FAILED, DownloadStatus.CANCELLED -> {
                        // Retry
                        Button(
                            onClick = onResume,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DarkSurfaceElevated,
                                contentColor = TodusGreen
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Reintentar", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(DarkSurfaceElevated)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Eliminar",
                                tint = ErrorRed,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    else -> {}
                }
            }
        }
    }
}

@Composable
fun StatusBadge(status: DownloadStatus) {
    val (label, bg, fg) = when (status) {
        DownloadStatus.COMPLETED -> Triple("Completada", TodusGreenContainer, TodusGreen)
        DownloadStatus.DOWNLOADING -> Triple("Descargando", EmeraldTeal.copy(alpha = 0.2f), EmeraldTeal)
        DownloadStatus.CONNECTING -> Triple("Conectando", CyanAccentColor.copy(alpha = 0.2f), CyanAccentColor)
        DownloadStatus.PAUSED -> Triple("Pausada", WarningAmber.copy(alpha = 0.2f), WarningAmber)
        DownloadStatus.FAILED -> Triple("Error", ErrorRed.copy(alpha = 0.2f), ErrorRed)
        DownloadStatus.CANCELLED -> Triple("Cancelada", ErrorRed.copy(alpha = 0.15f), ErrorRed)
        DownloadStatus.PENDING -> Triple("En cola", DarkSurfaceElevated, TextSecondary)
    }

    Surface(
        color = bg,
        shape = RoundedCornerShape(6.dp)
    ) {
        Text(
            text = label,
            color = fg,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

val CyanAccentColor = Color(0xFF00E5FF)

@Composable
fun EmptyDownloadsState(filter: DownloadFilterTab) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.Folder,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = when (filter) {
                    DownloadFilterTab.ALL -> "No hay descargas registradas"
                    DownloadFilterTab.ACTIVE -> "No hay descargas en curso"
                    DownloadFilterTab.COMPLETED -> "No hay descargas completadas"
                    DownloadFilterTab.FAILED -> "No hay descargas fallidas"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Pega un enlace en la pantalla de inicio para comenzar a descargar tus vídeos MP4 favoritos.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

private fun shareVideo(context: Context, filePath: String, fileName: String) {
    try {
        val file = File(filePath)
        if (!file.exists()) return

        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Compartir $fileName"))
    } catch (_: Exception) {
    }
}
