package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TodusApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Reset any downloads left in DOWNLOADING state when app starts
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AppDatabase.getInstance(this@TodusApp).downloadDao().pauseActiveDownloads()
            } catch (_: Exception) {
            }
        }
    }
}
